# FactorySense AI — Vercel Edition

Phone-friendly, one-click Vercel demo of the FactorySense AI Smart Manufacturing solution.

## Deploy from GitHub

1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. In Vercel: Add New → Project → import the repository.
4. Framework: Vite (auto-detected).
5. Build command: `npm run build`.
6. Output directory: `dist`.
7. Deploy.

No environment variable is required for the demo. If `VITE_API_URL` is later provided, the UI will consume the Spring Boot backend and automatically fall back to simulation if the API is unavailable.

## Production backend

The full Java/Spring Boot backend is included in `FULLSTACK_README.md` from the full-stack package. Deploy that backend separately to Railway/Render and set `VITE_API_URL=https://YOUR_BACKEND/api` in Vercel.
